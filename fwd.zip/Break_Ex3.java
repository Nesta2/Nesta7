import java.util.Scanner

public class Break_Ex3{
