import java.util.Scanner:

public class WhileLoopEx0{
public static void main(String{} args{
	int cnt = 0;
	Scanner input = new Scanner(System.in):

	While(cnt < 10 ){
	cnt = cnt + 1 ; 

	}
	System.out.println("Looped using counter control:"+cn+"times"):
	while(flag != -1){

    }
}