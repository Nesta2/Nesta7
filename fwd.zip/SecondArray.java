Public class SecondArray
{
   public static void main(String [] args)
   {
      int[] x = {128, 132, 8, 156, 18};

      System.out.println{"Index\tValue\n");

      for(int i = 0; i < x.length; i++){
	  System.out.println(i+"\t"+x[i]);
	  }
   }
}