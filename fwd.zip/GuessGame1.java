C:\Users\G00359956\OneDrive\GuessGame1.java:4: error: ';' expected
  public static void main(String[] args)[
                                        ^
C:\Users\G00359956\OneDrive\GuessGame1.java:9: error: <identifier> expected
    System.out.print("Guess a number from 1 to 10: ");
                    ^
C:\Users\G00359956\OneDrive\GuessGame1.java:9: error: illegal start of type
    System.out.print("Guess a number from 1 to 10: ");
                     ^
C:\Users\G00359956\OneDrive\GuessGame1.java:11: error: <identifier> expected
    System.out.println();
                      ^
C:\Users\G00359956\OneDrive\GuessGame1.java:12: error: illegal start of type
    if(guess == number){
    ^
C:\Users\G00359956\OneDrive\GuessGame1.java:12: error: <identifier> expected
    if(guess == number){
            ^
C:\Users\G00359956\OneDrive\GuessGame1.java:12: error: ';' expected
    if(guess == number){
               ^
C:\Users\G00359956\OneDrive\GuessGame1.java:12: error: illegal start of type
    if(guess == number){
                      ^
C:\Users\G00359956\OneDrive\GuessGame1.java:12: error: <identifier> expected
    if(guess == number){
                       ^
C:\Users\G00359956\OneDrive\GuessGame1.java:12: error: ';' expected
    if(guess == number){
                        ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: illegal start of type
       System.out.println("Good guess, it was "+number);
             ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: ';' expected
       System.out.println("Good guess, it was "+number);
                 ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: invalid method declaration; return type required
       System.out.println("Good guess, it was "+number);
                  ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: illegal start of type
       System.out.println("Good guess, it was "+number);
                          ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: ')' expected
       System.out.println("Good guess, it was "+number);
                                               ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: ';' expected
       System.out.println("Good guess, it was "+number);
                                                ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: illegal start of type
       System.out.println("Good guess, it was "+number);
                                                      ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: <identifier> expected
       System.out.println("Good guess, it was "+number);
                                                       ^
C:\Users\G00359956\OneDrive\GuessGame1.java:13: error: ';' expected
       System.out.println("Good guess, it was "+number);
                                                        ^
C:\Users\G00359956\OneDrive\GuessGame1.java:14: error: illegal start of type
    }else{
     ^
C:\Users\G00359956\OneDrive\GuessGame1.java:14: error: <identifier> expected
    }else{
         ^
C:\Users\G00359956\OneDrive\GuessGame1.java:14: error: ';' expected
    }else{
          ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: illegal start of type
       System.out.println("Bad guess, it was "+number);
             ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: ';' expected
       System.out.println("Bad guess, it was "+number);
                 ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: invalid method declaration; return type required
       System.out.println("Bad guess, it was "+number);
                  ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: illegal start of type
       System.out.println("Bad guess, it was "+number);
                          ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: ')' expected
       System.out.println("Bad guess, it was "+number);
                                              ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: ';' expected
       System.out.println("Bad guess, it was "+number);
                                               ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: illegal start of type
       System.out.println("Bad guess, it was "+number);
                                                     ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: <identifier> expected
       System.out.println("Bad guess, it was "+number);
                                                      ^
C:\Users\G00359956\OneDrive\GuessGame1.java:15: error: ';' expected
       System.out.println("Bad guess, it was "+number);
                                                       ^
C:\Users\G00359956\OneDrive\GuessGame1.java:17: error: <identifier> expected
    System.out.println();
                      ^
32 errors

Tool completed with exit code 1
